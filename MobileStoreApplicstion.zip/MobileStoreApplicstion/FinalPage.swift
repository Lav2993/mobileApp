//
//  ViewController.swift
//  MyTable
//
//  Created by user on 11/9/17.
//  Copyright © 2017 puneet. All rights reserved.
//

import UIKit

class FinalPage: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
    @IBOutlet weak var detailTableView: UITableView!
    
    @IBAction func order(_ sender: UIButton) {
        MyMain.check=1
        let userhome:UIViewController = (self.storyboard?.instantiateViewController(withIdentifier: "user") as? UserHome)!
        self.navigationController?.pushViewController(userhome, animated: true)
        
        }
    
    //@IBOutlet weak var AMOUNT: UITextField!
    let personNames: [String] = MyMain.myorder
    let personContacts: [String] = MyMain.myOrderPrice
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "wallpaper.jpg")!)
        self.initializeData();
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func initializeData(){
        self.detailTableView.tableFooterView = UIView()
        self.detailTableView.estimatedRowHeight = 100;
        self.detailTableView.rowHeight = UITableViewAutomaticDimension;
    }
    
    
    //MARK:-************************************DELEGATE METHOD CALLING********************************
    
    func numberOfSections(in tableView: UITableView) -> Int{
        return 1;
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return personNames.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath) as! MyCell
        
        cell.nameLabel.text = personNames[indexPath.row];
        cell.phoneLabel.text = personContacts[indexPath.row];
        return cell;
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}




