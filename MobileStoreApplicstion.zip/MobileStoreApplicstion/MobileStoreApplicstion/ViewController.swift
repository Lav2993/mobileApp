//
//  ViewController.swift
//  MobileStoreApplicstion
//
//  Created by Lavpreet Kaur on 2017-11-08.
//  Copyright © 2017 Lavpreet Kaur. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func reset(_ sender: UIButton) {
        uname.text=""
        pass.text=""
    }
    @IBAction func login(_ sender: UIButton) {
        
        if(uname.text! == "" || pass.text! == ""){
            let alert = UIAlertController(title: "Message", message: "All fields are required", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else{
            var u=MyMain.uname
            var p=MyMain.pass
            var status="0"
            var myindex=0
            for i in 0..<u.count{
                if(u[i]==uname.text!){
                    status="1"
                    myindex=Int(i)
                }
            }
            if(status=="1"){
                if(p[myindex]==pass.text!){
                    print("1")
                    let userhome:UIViewController = (self.storyboard?.instantiateViewController(withIdentifier: "user") as? UserHome)!
                    self.navigationController?.pushViewController(userhome, animated: true)
                    print("2")
                }else{
                    let alert = UIAlertController(title: "Oops!", message: "Wrong password", preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }else{
                let alert = UIAlertController(title: "Oops!", message: "Username is incorrect", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
    @IBOutlet weak var pass: UITextField!
    @IBOutlet weak var uname: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "wallpaper.jpg")!)
        // Do any additional setup after loading the view, typically from a nib.
        MyMain.uname=["pun","lav"]
        MyMain.pass=["123","123"]
        MyMain.name=["Puneet","Lavpreet"]
        MyMain.mob=["9876543211","9988776655"]
        navigationItem.hidesBackButton = true 
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

