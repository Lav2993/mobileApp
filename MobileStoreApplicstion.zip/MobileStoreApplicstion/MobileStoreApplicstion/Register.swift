//
//  Register.swift
//  MobileStoreApplicstion
//
//  Created by Lavpreet Kaur on 2017-11-09.
//  Copyright © 2017 Lavpreet Kaur. All rights reserved.
//

import Foundation
import UIKit

class Register: UIViewController {
    
    @IBAction func reg(_ sender: Any) {
        if(unamereg.text!=="" || namereg.text!=="" || phonereg.text!=="" || passreg.text!==""){
            let alert = UIAlertController(title: "Alert!!", message: "All Fileds are required", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
            
        }else{
            MyMain.uname.append(unamereg.text!)
            MyMain.name.append(namereg.text!)
            MyMain.pass.append(passreg.text!)
            MyMain.phone.append(phonereg.text!)
            unamereg.text=""
            namereg.text=""
            passreg.text=""
            phonereg.text=""
            let alert = UIAlertController(title: "Alert!!", message: "Data Updated", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        }
    }
    @IBOutlet weak var phonereg: UITextField!
    @IBOutlet weak var passreg: UITextField!
    @IBOutlet weak var unamereg: UITextField!
    @IBOutlet weak var namereg: UITextField!
    override func viewDidLoad() {
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "wallpaper.jpg")!)
    }
    
}



