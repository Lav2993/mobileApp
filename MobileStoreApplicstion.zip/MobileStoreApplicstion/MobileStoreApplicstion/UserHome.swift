import UIKit
import MapKit
import CoreLocation


import Foundation
class  UserHome: UIViewController, UIPickerViewDataSource,UIPickerViewDelegate , UITextFieldDelegate ,UITextViewDelegate,MKMapViewDelegate
{
    var isInitialLoad = true;
    var firstCountryIndex = -1;
    var secondCountryIndex = -1;
    @IBOutlet weak var mapView: MKMapView!
    
    @IBOutlet weak var cityDropButton: UIButton!
    @IBOutlet weak var locDropT: UIButton!
    @IBOutlet weak var locDropM: UIButton!
    @IBOutlet weak var Tloc: UIPickerView!
    @IBOutlet weak var mloc: UIPickerView!
    @IBOutlet weak var locDrop: UIPickerView!
    @IBOutlet weak var cityDrop: UIPickerView!
    @IBOutlet weak var locDropButton: UIButton!
    var status=0
    @IBOutlet weak var selectorUIView: UIView!
    
    @IBAction func cityAction(_ sender: UIButton) {
        status=1
        self.selectorUIView.isHidden = false;
        self.cityDrop.isHidden = false;
        self.locDrop.isHidden = true;
        self.mloc.isHidden = true;
        self.Tloc.isHidden = true;
        
    }
    
    @IBAction func locAction(_ sender: UIButton) {
        status=2
        self.selectorUIView.isHidden = false;
        self.cityDrop.isHidden = true;
        self.locDrop.isHidden = false;
        self.mloc.isHidden = true;
        self.Tloc.isHidden = true;
        
    }
    @IBAction func locActionT(_ sender: UIButton) {
        status=4
        self.selectorUIView.isHidden = false;
        self.cityDrop.isHidden = true;
        self.locDrop.isHidden = true;
        self.mloc.isHidden = true;
        self.Tloc.isHidden = false;
    }
    
    @IBAction func locActionM(_ sender: UIButton) {
        status=3
        self.selectorUIView.isHidden = false;
        self.cityDrop.isHidden = true;
        self.locDrop.isHidden = true;
        self.mloc.isHidden = false;
        self.Tloc.isHidden = true;
    }
    @IBAction func doneaction(_ sender: UIButton) {
       self.selectorUIView.isHidden = true;
    }

    var menu=["Select City","Brampton","Missisauga","Torronto"]
    var locmenu=["Shoppers World","Bramley City centre","Trinity Common Centre"]
    var mloca=["Square One","HeartLand Town Centre","Dixie Mall"]
    var tloc=["Fairview Mall","Yorkdale Mall"]
    let locations = [
        ["title": "Select Country",    "latitude": 0.0, "longitude": 0.0],
        ["title": "Brampton", "latitude": 43.6833 , "longitude": -79.7666],
        ["title": "Toronto",     "latitude": 43.6532, "longitude":-79.3832],
        ["title": "Mississauga",     "latitude":43.5890 , "longitude":-79.6441]
    ]
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.hidesBackButton = true
        
        if(MyMain.check==1){
            var messg="Congratulations! Your Order is placed.You Can pick your items from \(MyMain.loc) in \(MyMain.city)"
            let alert = UIAlertController(title: "Message", message: messg, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        }
        MyMain.loc=""
        MyMain.city=""
        MyMain.check=0
        MyMain.myorder=[String]()
        MyMain.myOrderPrice=[String]()
        
        self.initializeData();
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.hideKeyboardOnClick(_:)))
        self.view.addGestureRecognizer(tapGesture);
        
    }
    func initializeData(){
        
        self.mapView.delegate = self;
        self.addMarkersToMap();
    }
    func addMarkersToMap(){
        
        var i = 0;
        var pinColor = UIColor.blue;
        for location in locations {
            switch i {
            case 0:
                pinColor = UIColor.blue;
                break;
            case 1:
                pinColor = UIColor.yellow;
                break;
            case 2:
                pinColor = UIColor.green;
                break;
            case 3:
                pinColor = UIColor.gray;
                break;
                
            default:
                pinColor = UIColor.orange;
                break;
            }
            i += 1;
            let annotation = ColorPointAnnotation();
            annotation.pinColor = pinColor;
            //let annotation = MKPointAnnotation();
            annotation.title = location["title"] as? String
            annotation.coordinate = CLLocationCoordinate2D(latitude: location["latitude"] as! Double, longitude: location["longitude"] as! Double)
            if(annotation.title != "Select Country"){
                mapView.addAnnotation(annotation);
            }
            isInitialLoad = true;
        }
    }
    
    
    func mapView(_ map: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        if let pin = annotation as? ColorPointAnnotation {
            
            let identifier = "pinAnnotation"
            
            if let view = map.dequeueReusableAnnotationView(withIdentifier: identifier) as? MKPinAnnotationView {
                
                view.pinTintColor = pin.pinColor
                
                return view
                
            } else {
                
                let view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
                
                view.canShowCallout = true
                
                view.pinTintColor = pin.pinColor
                
                return view
            }
        }
        
        return nil
    }
    
    override func viewDidLayoutSubviews() {
        if isInitialLoad {
            self.fitMapViewToAnnotaionList(annotations: mapView.annotations as! [MKPointAnnotation]);
            isInitialLoad = false;
        }
    }
    
    func fitMapViewToAnnotaionList(annotations: [MKPointAnnotation]) -> Void {
        let mapEdgePadding = UIEdgeInsets(top: 20, left: 20, bottom: 20, right: 20)
        var zoomRect:MKMapRect = MKMapRectNull
        
        for index in 0..<annotations.count {
            let annotation = annotations[index]
            let aPoint:MKMapPoint = MKMapPointForCoordinate(annotation.coordinate)
            let rect:MKMapRect = MKMapRectMake(aPoint.x, aPoint.y, 0.1, 0.1)
            
            if MKMapRectIsNull(zoomRect) {
                zoomRect = rect
            } else {
                zoomRect = MKMapRectUnion(zoomRect, rect)
            }
        }
        mapView.setVisibleMapRect(zoomRect, edgePadding: mapEdgePadding, animated: true)
    }
    
    //TODO: - Display Error Message
    func displayErrorMessage(errorTitle : String, errorMessage : String){
        let alertController = UIAlertController(title: errorTitle, message:
            errorMessage, preferredStyle: UIAlertControllerStyle.alert)
        alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default,handler: nil))
        self.present(alertController, animated: true, completion: nil)
    }
    @objc func hideKeyboardOnClick(_ sender: UITapGestureRecognizer) {
        self.view.endEditing(true);
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


    @IBAction func logout(_ sender: UIButton) {
          let view:UIViewController = (self.storyboard?.instantiateViewController(withIdentifier: "view") as? ViewController)!
         self.navigationController?.pushViewController(view, animated: true)
        
    }
    @IBAction func cityDropAction(_ sender: UIButton) {
       // locDropButton.isHidden=true
        //locDropM.isHidden=true
        //locDropT.isHidden=true
    }

    @IBAction func gobtn(_ sender: UIButton) {
    
        MyMain.city=(cityDropButton.titleLabel?.text!)!
        
        if(locDropButton.isHidden==false){
            MyMain.loc=(locDropButton.titleLabel?.text!)!
        }
        if(locDropM.isHidden==false){
            MyMain.loc=(locDropM.titleLabel?.text!)!
        }
        if(locDropT.isHidden==false){
            MyMain.loc=(locDropT.titleLabel?.text!)!
        }
        let pur:UIViewController = (self.storyboard?.instantiateViewController(withIdentifier: "product") as? Products)!
        self.navigationController?.pushViewController(pur, animated: true)
     
        
    }
    
    @IBAction func search(_ sender: UIButton) {
       
      let city=cityDropButton.titleLabel?.text!
        
        
         if(city=="Select City"){
            print("ho")
            locDropButton.isHidden=true
            mloc.isHidden=true
            Tloc.isHidden=true
            
            
        }else if(city=="Brampton"){
            locDropButton.isHidden=false
            mloc.isHidden=true
            Tloc.isHidden=true
            
        }else if(city=="Missisauga"){
            locDropButton.isHidden=true
            locDropM.isHidden=false
            Tloc.isHidden=true
            
        }else if(city=="Torronto"){
            locDropButton.isHidden=true
            mloc.isHidden=true
            Tloc.isHidden=false
            
        }
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        
        if(pickerView==cityDrop){
            return menu.count
        }else if(pickerView==locDrop){
            return locmenu.count
        }else if(pickerView==mloc){
            return mloca.count
        }else if(pickerView==Tloc){
            return tloc.count
        }
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if(pickerView==cityDrop){
            return menu[row]
        }else if(pickerView==locDrop){
            return locmenu[row]
        }else if(pickerView==mloc){
            return mloca[row]
        }else if(pickerView==Tloc){
            return tloc[row]
        }
        return ""
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if(pickerView==cityDrop){
            self.cityDropButton.setTitle(menu[row], for: .normal);
        }else if(pickerView==locDrop){
            self.locDropButton.setTitle(locmenu[row], for: .normal);
        }else if(pickerView==mloc){
            self.locDropM.setTitle(mloca[row], for: .normal);
        }else if(pickerView==Tloc){
            self.locDropT.setTitle(tloc[row], for: .normal);
        }
        
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return true;
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
    }
    
   
}
class ColorPointAnnotation: MKPointAnnotation {
    var pinColor: UIColor
    
    override init() {
        self.pinColor = .purple;
        super.init()
    }
}


