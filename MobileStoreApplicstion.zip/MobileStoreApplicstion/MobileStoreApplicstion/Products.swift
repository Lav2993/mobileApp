//
//  ViewController.swift
//  MyTable
//
//  Created by user on 11/9/17.
//  Copyright © 2017 puneet. All rights reserved.
//

import UIKit

class Products: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var tot=0
    @IBAction func proceed(_ sender: UIButton) {
        if(tot==0){
            let alert = UIAlertController(title: "Alert!!", message: "Please select any product", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else{
            let final:UIViewController = (self.storyboard?.instantiateViewController(withIdentifier: "final") as? FinalPage)!
            self.navigationController?.pushViewController(final, animated: true)
        }
    }
    @IBOutlet weak var detailTableView: UITableView!
    
    @IBOutlet weak var amount: UITextField!
    //@IBOutlet weak var AMOUNT: UITextField!
    let personNames: [String] = ["IPhone 4", "IPhone 5", "IPhone 6", "IPhone 7", "IPhone 8"]
    let personContacts: [String] = ["300", "450", "600", "800", "1100"]
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.initializeData();
        navigationItem.hidesBackButton=true
        amount.text=String(tot)
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func initializeData(){
        self.detailTableView.tableFooterView = UIView()
        self.detailTableView.estimatedRowHeight = 100;
        self.detailTableView.rowHeight = UITableViewAutomaticDimension;
    }
    
    
    //MARK:-************************************DELEGATE METHOD CALLING********************************
    
    func numberOfSections(in tableView: UITableView) -> Int{
        return 1;
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return personNames.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath) as! MyCell
        
        cell.nameLabel.text = personNames[indexPath.row];
        cell.phoneLabel.text = personContacts[indexPath.row];
        cell.statusButton.tag = indexPath.row;
        
        cell.statusButton.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        return cell;
        
    }
    
    //When you click on Status button this will print index of that row
    @objc func buttonAction(sender: UIButton!) {
       
        let priceitem = personContacts[sender.tag];
        let name = personNames[sender.tag];
        
        MyMain.myorder.append(name)
        MyMain.myOrderPrice.append(priceitem)
        tot=tot+Int(priceitem)!
        
        amount.text = String(tot)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}



