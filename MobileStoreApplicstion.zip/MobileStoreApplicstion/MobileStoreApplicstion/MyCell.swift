//
//  MyCell.swift
//  MyTable
//
//  Created by user on 11/9/17.
//  Copyright © 2017 puneet. All rights reserved.
//

import UIKit

class MyCell: UITableViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var phoneLabel: UILabel!
    
    @IBOutlet weak var statusButton: UIButton!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        //        self.phoneLabel.layer.cornerRadius = 1.0;
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}


