//
//  File.swift
//  MobileStoreApplicstion
//
//  Created by Lavpreet Kaur on 2017-11-08.
//  Copyright © 2017 Lavpreet Kaur. All rights reserved.
//

import Foundation
class MyMain{
    
    static var uname=[String]()
    static var pass=[String]()
    static var mob=[String]()
    static var name=[String]()
    
    
    static var city=""
    static var loc=""
    static var phone=[String]()
    static var price=[Int]()
    static var myorder=[String]()
    static var myOrderPrice=[String]()
    static var check=0
    
}
